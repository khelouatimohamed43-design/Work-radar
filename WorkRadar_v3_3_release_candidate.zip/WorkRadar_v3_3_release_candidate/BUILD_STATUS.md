# WorkRadar v3.2 Build Status

Android project scaffold and GitHub Actions workflow are included.
The next real verification is a successful Flutter/Android CI build, which will produce an APK and AAB artifact.
