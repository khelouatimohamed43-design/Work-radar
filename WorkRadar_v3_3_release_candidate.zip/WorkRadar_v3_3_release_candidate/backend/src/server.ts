import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import pg from 'pg';
import bcrypt from 'bcryptjs';
import {askAI} from './ai.js';

dotenv.config();
const {Pool}=pg;
const db=new Pool({connectionString:process.env.DATABASE_URL});
const app=express();
app.disable('x-powered-by');
app.use((req,res,next)=>{
 res.setHeader('X-Content-Type-Options','nosniff');
 res.setHeader('X-Frame-Options','DENY');
 res.setHeader('Referrer-Policy','no-referrer');
 res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');
 next();
});
const allowedOrigins=(process.env.CORS_ORIGIN||'').split(',').map(x=>x.trim()).filter(Boolean);
if(process.env.NODE_ENV==='production' && !allowedOrigins.length) throw new Error('CORS_ORIGIN is required in production');
app.use(cors({origin:allowedOrigins.length?allowedOrigins:true,credentials:allowedOrigins.length>0}));
app.use(express.json({limit:'1mb'}));
app.use(rateLimit({windowMs:15*60*1000,max:300,standardHeaders:true,legacyHeaders:false}));

if(!process.env.JWT_SECRET && process.env.NODE_ENV==='production') throw new Error('JWT_SECRET is required in production');
const secret=process.env.JWT_SECRET||'development-only-secret-change-me';
const tokenFor=(userId:string)=>jwt.sign({userId},secret,{expiresIn:'30d'});
const auth=(req:any,res:any,next:any)=>{
 const h=req.headers.authorization;
 if(!h?.startsWith('Bearer '))return res.status(401).json({error:'Authentication required'});
 try{req.userId=(jwt.verify(h.slice(7),secret)as any).userId;next();}
 catch{return res.status(401).json({error:'Invalid token'});}
};

function match(p:any,o:any){
 let s=20;const reasons:string[]=[];
 const dev=p.devices||[],need=o.required_devices||[];
 if(!need.length)s+=10;
 else if(need.every((d:string)=>dev.includes(d))){s+=30;reasons.push('الأجهزة متوفرة');}
 const skills=(p.skills||[]).map((x:string)=>String(x).toLowerCase()),req=o.required_skills||[];
 if(!req.length)s+=10;
 else{
  const m=req.filter((x:string)=>skills.includes(String(x).toLowerCase()));
  s+=Math.round(m.length/req.length*20);
  if(m.length)reasons.push('مهارات مطابقة');
 }
 if((p.goals||[]).includes('income')){s+=10;reasons.push('هدف الدخل');}
 if(!o.minimum_hours||Number(p.available_hours_per_day||0)>=Number(o.minimum_hours)){s+=10;reasons.push('الوقت مناسب');}
 return {score:Math.min(100,s),reason:reasons.join(' • ')};
}

app.get('/health',async(_,r)=>{
 try{await db.query('SELECT 1');r.json({status:'ok',app:'WorkRadar',version:'2.8.0',database:'ok'});}
 catch{r.status(503).json({status:'degraded',app:'WorkRadar',version:'2.8.0',database:'unavailable'});}
});

const authLimiter=rateLimit({windowMs:15*60*1000,max:20,standardHeaders:true,legacyHeaders:false,message:{error:'Too many authentication attempts. Please try again later.'}});

app.post('/api/auth/register',authLimiter,async(req,res)=>{
 const {email,password}=req.body||{};
 if(!email||!password||String(password).length<10)return res.status(400).json({error:'Email and password (10+ characters) required'});
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email).trim()))return res.status(400).json({error:'Valid email required'});
 try{
  const hash=await bcrypt.hash(String(password),12);
  const x=await db.query('INSERT INTO users(email,password_hash) VALUES($1,$2) RETURNING id,email',[String(email).toLowerCase().trim(),hash]);
  const user=x.rows[0];
  await db.query('INSERT INTO user_profiles(user_id) VALUES($1)',[user.id]);
  res.status(201).json({token:tokenFor(user.id),user:{id:user.id,email:user.email}});
 }catch(e:any){
  if(e.code==='23505')return res.status(409).json({error:'Email already exists'});
  res.status(500).json({error:'Registration failed'});
 }
});

app.post('/api/auth/login',authLimiter,async(req,res)=>{
 const {email,password}=req.body||{};
 const x=await db.query('SELECT * FROM users WHERE email=$1',[String(email||'').toLowerCase().trim()]);
 const user=x.rows[0];
 if(!user||!await bcrypt.compare(String(password||''),user.password_hash))return res.status(401).json({error:'Invalid email or password'});
 res.json({token:tokenFor(user.id),user:{id:user.id,email:user.email}});
});

app.get('/api/me/profile',auth,async(req:any,res)=>{
 const x=await db.query('SELECT * FROM user_profiles WHERE user_id=$1',[req.userId]);
 res.json({profile:x.rows[0]||{}});
});

app.put('/api/me/profile',auth,async(req:any,res)=>{
 const d=req.body||{};
 const x=await db.query(`INSERT INTO user_profiles(user_id,display_name,devices,skills,goals,available_hours_per_day,experience_level,language)
 VALUES($1,$2,$3,$4,$5,$6,$7,$8)
 ON CONFLICT(user_id) DO UPDATE SET display_name=EXCLUDED.display_name,devices=EXCLUDED.devices,skills=EXCLUDED.skills,goals=EXCLUDED.goals,available_hours_per_day=EXCLUDED.available_hours_per_day,experience_level=EXCLUDED.experience_level,language=EXCLUDED.language,updated_at=NOW() RETURNING *`,
 [req.userId,String(d.displayName||'').trim().slice(0,120)||null,JSON.stringify(Array.isArray(d.devices)?d.devices.slice(0,20):[]),JSON.stringify(Array.isArray(d.skills)?d.skills.slice(0,100):[]),JSON.stringify(Array.isArray(d.goals)?d.goals.slice(0,20):[]),Math.max(0,Math.min(24,Number(d.availableHours??1)||0)),String(d.experienceLevel||'beginner').slice(0,50),['ar','en','fr'].includes(d.language)?d.language:'ar']);
 res.json({profile:x.rows[0]});
});

app.get('/api/dashboard',auth,async(req:any,res)=>{
 const [opp,saved,alerts]=await Promise.all([
  db.query("SELECT COUNT(*)::int n FROM opportunities WHERE status='active'"),
  db.query('SELECT COUNT(*)::int n FROM saved_opportunities WHERE user_id=$1',[req.userId]),
  db.query('SELECT COUNT(*)::int n FROM opportunity_alerts WHERE user_id=$1 AND is_read=false',[req.userId])
 ]);
 res.json({activeOpportunities:opp.rows[0].n,saved:saved.rows[0].n,unreadAlerts:alerts.rows[0].n});
});

app.get('/api/opportunities',auth,async(req:any,res)=>{
 const p=(await db.query('SELECT * FROM user_profiles WHERE user_id=$1',[req.userId])).rows[0]||{};
 const rows=(await db.query("SELECT * FROM opportunities WHERE status='active' ORDER BY created_at DESC")).rows;
 res.json({opportunities:rows.map((o:any)=>({...o,match:match(p,o)})).sort((a:any,b:any)=>b.match.score-a.match.score)});
});
app.post('/api/opportunities/:id/save',auth,async(req:any,res)=>{
 await db.query('INSERT INTO saved_opportunities(user_id,opportunity_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.userId,req.params.id]);
 res.json({saved:true});
});
app.get('/api/opportunities/saved',auth,async(req:any,res)=>{
 const x=await db.query('SELECT o.* FROM opportunities o JOIN saved_opportunities s ON s.opportunity_id=o.id WHERE s.user_id=$1',[req.userId]);
 res.json({opportunities:x.rows});
});

app.get('/api/alerts',auth,async(req:any,res)=>{
 const x=await db.query('SELECT a.*,o.title,o.description FROM opportunity_alerts a JOIN opportunities o ON o.id=a.opportunity_id WHERE a.user_id=$1 ORDER BY a.created_at DESC',[req.userId]);
 res.json({alerts:x.rows});
});
app.post('/api/alerts/:id/read',auth,async(req:any,res)=>{
 await db.query('UPDATE opportunity_alerts SET is_read=true WHERE id=$1 AND user_id=$2',[req.params.id,req.userId]);
 res.json({ok:true});
});

app.get('/api/radar',auth,async(req:any,res)=>{
 const x=await db.query('SELECT * FROM radar_filters WHERE user_id=$1',[req.userId]);
 res.json({radar:x.rows[0]||{minimum_match:50,enabled:true}});
});
app.post('/api/radar',auth,async(req:any,res)=>{
 const d=req.body||{};
 const x=await db.query('INSERT INTO radar_filters(user_id,categories,minimum_match,enabled) VALUES($1,$2,$3,$4) ON CONFLICT(user_id) DO UPDATE SET categories=EXCLUDED.categories,minimum_match=EXCLUDED.minimum_match,enabled=EXCLUDED.enabled,updated_at=NOW() RETURNING *',[req.userId,JSON.stringify(d.categories||[]),d.minimumMatch??50,d.enabled??true]);
 res.json({radar:x.rows[0]});
});



// WorkRadar Inbox — foundation for assistant/agent updates and professional activity.
app.get('/api/inbox',auth,async(req:any,res)=>{
 const x=await db.query('SELECT id,type,title,body,metadata,is_read,created_at FROM inbox_messages WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100',[req.userId]);
 res.json({messages:x.rows});
});
app.post('/api/inbox/:id/read',auth,async(req:any,res)=>{
 await db.query('UPDATE inbox_messages SET is_read=true WHERE id=$1 AND user_id=$2',[req.params.id,req.userId]);
 res.json({ok:true});
});
app.post('/api/tasks',auth,async(req:any,res)=>{
 const title=String(req.body.title||'').trim();
 if(!title)return res.status(400).json({error:'Task title required'});
 const x=await db.query('INSERT INTO agent_tasks(user_id,title,instructions,status,schedule) VALUES($1,$2,$3,$4,$5) RETURNING *',[req.userId,title,String(req.body.instructions||''), 'active', req.body.schedule||null]);
 await db.query('INSERT INTO inbox_messages(user_id,type,title,body,metadata) VALUES($1,$2,$3,$4,$5)',[req.userId,'agent','مهمة جديدة للمساعد','تم تسجيل المهمة: '+title,JSON.stringify({taskId:x.rows[0].id})]);
 res.status(201).json({task:x.rows[0]});
});
app.get('/api/tasks',auth,async(req:any,res)=>{
 const x=await db.query('SELECT * FROM agent_tasks WHERE user_id=$1 ORDER BY created_at DESC',[req.userId]);
 res.json({tasks:x.rows});
});
app.patch('/api/tasks/:id/status',auth,async(req:any,res)=>{
 const status=String(req.body?.status||'');
 if(!['active','paused','cancelled'].includes(status))return res.status(400).json({error:'Invalid task status'});
 const x=await db.query('UPDATE agent_tasks SET status=$3,updated_at=NOW() WHERE id=$1 AND user_id=$2 RETURNING *',[req.params.id,req.userId,status]);
 if(!x.rows[0])return res.status(404).json({error:'Task not found'});
 res.json({task:x.rows[0]});
});
app.get('/api/inbox/unread-count',auth,async(req:any,res)=>{
 const x=await db.query('SELECT COUNT(*)::int n FROM inbox_messages WHERE user_id=$1 AND is_read=false',[req.userId]);
 res.json({unread:x.rows[0].n});
});


// Internal worker authentication must be declared before internal routes.
const workerAuth=(req:any,res:any,next:any)=>{
 const key=req.headers['x-worker-secret'];
 if(!process.env.WORKER_SECRET||key!==process.env.WORKER_SECRET)return res.status(401).json({error:'Worker authentication failed'});
 next();
};

// Agent execution helpers: real WorkRadar data is used for safe opportunity monitoring.
app.get('/internal/agent/opportunities/:userId',workerAuth,async(req,res)=>{
 const userId=req.params.userId;
 const profile=(await db.query('SELECT * FROM user_profiles WHERE user_id=$1',[userId])).rows[0]||{};
 const radar=(await db.query('SELECT * FROM radar_filters WHERE user_id=$1',[userId])).rows[0]||{minimum_match:50,enabled:true};
 if(!radar.enabled)return res.json({opportunities:[],minimumMatch:radar.minimum_match,disabled:true});
 const rows=(await db.query("SELECT * FROM opportunities WHERE status='active' ORDER BY created_at DESC LIMIT 100")).rows;
 const minimum=Number(radar.minimum_match||50);
 const matched=rows.map((o:any)=>({opportunity:o,match:match(profile,o)})).filter((x:any)=>x.match.score>=minimum).sort((a:any,b:any)=>b.match.score-a.match.score);
 res.json({opportunities:matched,minimumMatch:minimum});
});
app.post('/internal/agent/opportunities/:userId/notify',workerAuth,async(req,res)=>{
 const userId=req.params.userId; const items=Array.isArray(req.body?.items)?req.body.items:[];
 const inserted:any[]=[];
 for(const item of items.slice(0,10)){
  const o=item.opportunity; const m=item.match;
  if(!o?.id)continue;
  const q=await db.query(`INSERT INTO opportunity_alerts(user_id,opportunity_id,match_score,reason)
   VALUES($1,$2,$3,$4) ON CONFLICT(user_id,opportunity_id) DO NOTHING RETURNING id`,[userId,o.id,m?.score||0,m?.reason||'فرصة مطابقة']);
  if(q.rows[0])inserted.push({title:o.title,score:m?.score||0});
 }
 if(inserted.length){
  const best=inserted[0];
  await db.query(`INSERT INTO inbox_messages(user_id,type,title,body,metadata) VALUES($1,'opportunity',$2,$3,$4)`,[userId,'🔎 Opportunity Hunter وجد فرصًا',`وجدت ${inserted.length} فرصة جديدة مناسبة. أفضل تطابق: ${best.title} (${best.score}%).`,JSON.stringify({items:inserted})]);
 }
 res.json({inserted});
});

// Worker API: background service claims due tasks and reports results.
app.get('/internal/worker/tasks',workerAuth,async(req,res)=>{
 const x=await db.query(`SELECT * FROM agent_tasks WHERE status='active' AND (next_run_at IS NULL OR next_run_at<=NOW()) ORDER BY COALESCE(next_run_at,created_at) ASC LIMIT 10`);
 res.json({tasks:x.rows});
});
app.post('/internal/worker/tasks/:id/run',workerAuth,async(req,res)=>{
 const task=(await db.query(`UPDATE agent_tasks SET next_run_at=NOW()+INTERVAL '5 minutes', updated_at=NOW() WHERE id=$1 AND status='active' AND (next_run_at IS NULL OR next_run_at<=NOW()) RETURNING *`,[req.params.id])).rows[0];
 if(!task)return res.status(409).json({error:'Task is not due or already claimed'});
 const run=(await db.query(`INSERT INTO agent_task_runs(task_id,user_id,status,started_at) VALUES($1,$2,'running',NOW()) RETURNING *`,[task.id,task.user_id])).rows[0];
 res.json({task,run});
});
app.post('/internal/worker/runs/:id/complete',workerAuth,async(req,res)=>{
 const run=(await db.query('SELECT * FROM agent_task_runs WHERE id=$1',[req.params.id])).rows[0];
 if(!run)return res.status(404).json({error:'Run not found'});
 const d=req.body||{};
 await db.query(`UPDATE agent_task_runs SET status=$2,summary=$3,result=$4,finished_at=NOW() WHERE id=$1`,[run.id,d.status||'completed',String(d.summary||''),JSON.stringify(d.result||{})]);
 const task=(await db.query('SELECT * FROM agent_tasks WHERE id=$1',[run.task_id])).rows[0];
 const nextMinutes=Math.max(5,Number(task?.schedule?.everyMinutes||60));
 await db.query(`UPDATE agent_tasks SET last_run_at=NOW(),next_run_at=NOW()+($2::text||' minutes')::interval,run_count=run_count+1,updated_at=NOW() WHERE id=$1`,[run.task_id,String(nextMinutes)]);
 await db.query(`INSERT INTO inbox_messages(user_id,type,title,body,metadata) VALUES($1,'agent',$2,$3,$4)`,[run.user_id,'🤖 المساعد أكمل مهمة',String(d.summary||'تم تنفيذ المهمة'),JSON.stringify({taskId:run.task_id,runId:run.id,result:d.result||{}})]);
 res.json({ok:true});
});
app.get('/api/tasks/:id/runs',auth,async(req:any,res)=>{
 const x=await db.query('SELECT r.* FROM agent_task_runs r JOIN agent_tasks t ON t.id=r.task_id WHERE r.task_id=$1 AND t.user_id=$2 ORDER BY r.created_at DESC LIMIT 30',[req.params.id,req.userId]);
 res.json({runs:x.rows});
});


// Autonomous command layer: converts natural-language intent into safe, typed tasks.
app.post('/api/assistant/command',auth,async(req:any,res)=>{
 const command=String(req.body.command||'').trim();
 if(!command)return res.status(400).json({error:'Command required'});
 const lower=command.toLowerCase();
 let kind='general';
 if(/فرص|وظيف|عمل|job|opportun/.test(lower))kind='opportunity_monitor';
 else if(/سيرة|cv|resume/.test(lower))kind='cv_review';
 else if(/طلب|application|تقديم/.test(lower))kind='application_followup';
 const title=kind==='opportunity_monitor'?'مراقبة فرص العمل':kind==='cv_review'?'مراجعة وتحسين السيرة الذاتية':kind==='application_followup'?'متابعة طلبات التقديم':'مهمة للمساعد';
 const task=(await db.query(`INSERT INTO agent_tasks(user_id,title,instructions,status,schedule) VALUES($1,$2,$3,'active',$4) RETURNING *`,[req.userId,title,command,JSON.stringify(req.body.schedule||{everyMinutes:60})])).rows[0];
 await db.query(`INSERT INTO inbox_messages(user_id,type,title,body,metadata) VALUES($1,'agent',$2,$3,$4)`,[req.userId,'🤖 تم استلام أمرك',`بدأ المساعد تجهيز المهمة: ${title}`,JSON.stringify({taskId:task.id,kind})]);
 res.status(201).json({task,kind,message:'تم إنشاء المهمة وسيبدأ المساعد متابعتها في الخلفية.'});
});

app.post('/api/devices/register',auth,async(req:any,res)=>{
 const {token,platform,language}=req.body||{};
 if(!token)return res.status(400).json({error:'Device token required'});
 await db.query('INSERT INTO device_tokens(user_id,token,platform,language) VALUES($1,$2,$3,$4) ON CONFLICT(user_id,token) DO UPDATE SET platform=EXCLUDED.platform,language=EXCLUDED.language',[req.userId,token,platform||null,language||'ar']);
 res.json({ok:true});
});

app.get('/api/assistant/history',auth,async(req:any,res)=>{
 const x=await db.query('SELECT role,content,created_at FROM assistant_messages WHERE user_id=$1 ORDER BY created_at ASC LIMIT 100',[req.userId]);
 res.json({messages:x.rows});
});
app.post('/api/assistant/chat',auth,async(req:any,res)=>{
 const text=String(req.body.message||'').trim();
 if(!text)return res.status(400).json({error:'Message required'});
 await db.query("INSERT INTO assistant_messages(user_id,role,content) VALUES($1,'user',$2)",[req.userId,text]);
 const profile=(await db.query('SELECT * FROM user_profiles WHERE user_id=$1',[req.userId])).rows[0]||{};
 const opportunities=(await db.query("SELECT title,description,category FROM opportunities WHERE status='active' LIMIT 20")).rows;
 const history=(await db.query('SELECT role,content FROM assistant_messages WHERE user_id=$1 ORDER BY created_at DESC LIMIT 12',[req.userId])).rows.reverse();
 try{
  const answer=await askAI(history,{profile,opportunities});
  await db.query("INSERT INTO assistant_messages(user_id,role,content) VALUES($1,'assistant',$2)",[req.userId,answer]);
  res.json({answer});
 }catch(e:any){res.status(503).json({error:e.message});}
});

app.post('/api/workshop/action',auth,async(req:any,res)=>{
 const {type,prompt}=req.body||{};
 const allowed=['writing','cv','image_prompt'];
 if(!allowed.includes(type))return res.status(400).json({error:'Unknown action'});
 const result=await askAI([{role:'user',content:`Workshop ${type}: ${prompt}`}],{});
 res.json({result});
});

// v2.0 routes are defined below.



// Application Tracker — keeps the user's job applications in one place.
app.get('/api/applications',auth,async(req:any,res)=>{
 const x=await db.query('SELECT * FROM applications WHERE user_id=$1 ORDER BY updated_at DESC',[req.userId]);
 res.json({applications:x.rows});
});
app.post('/api/applications',auth,async(req:any,res)=>{
 const d=req.body||{}; const role=String(d.roleTitle||'').trim();
 if(!role)return res.status(400).json({error:'roleTitle required'});
 const x=await db.query(`INSERT INTO applications(user_id,opportunity_id,company,role_title,status,notes,applied_at,follow_up_at)
 VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,[req.userId,d.opportunityId||null,d.company||null,role,d.status||'planned',d.notes||'',d.appliedAt||null,d.followUpAt||null]);
 await db.query(`INSERT INTO inbox_messages(user_id,type,title,body,metadata) VALUES($1,'application','📝 تمت إضافة طلب جديد','سيقوم Application Tracker بمتابعة حالة الطلب.', $2)`,[req.userId,JSON.stringify({applicationId:x.rows[0].id})]);
 res.status(201).json({application:x.rows[0]});
});
app.put('/api/applications/:id',auth,async(req:any,res)=>{
 const d=req.body||{};
 const x=await db.query(`UPDATE applications SET company=COALESCE($3,company),role_title=COALESCE($4,role_title),status=COALESCE($5,status),notes=COALESCE($6,notes),follow_up_at=COALESCE($7,follow_up_at),updated_at=NOW() WHERE id=$1 AND user_id=$2 RETURNING *`,[req.params.id,req.userId,d.company,d.roleTitle,d.status,d.notes,d.followUpAt]);
 if(!x.rows[0])return res.status(404).json({error:'Application not found'});
 res.json({application:x.rows[0]});
});

// Marketplace — safe foundation; payments are intentionally external until a verified provider is integrated.
app.get('/api/marketplace',auth,async(_req,res)=>{
 const x=await db.query(`SELECT l.*,p.display_name FROM marketplace_listings l LEFT JOIN user_profiles p ON p.user_id=l.user_id WHERE l.status='published' ORDER BY l.created_at DESC LIMIT 100`);
 res.json({listings:x.rows});
});
app.get('/api/marketplace/mine',auth,async(req:any,res)=>{
 const x=await db.query('SELECT * FROM marketplace_listings WHERE user_id=$1 ORDER BY created_at DESC',[req.userId]);res.json({listings:x.rows});
});
app.post('/api/marketplace',auth,async(req:any,res)=>{
 const d=req.body||{};const title=String(d.title||'').trim();if(!title)return res.status(400).json({error:'Title required'});if(title.length>200)return res.status(400).json({error:'Title too long'});
 const allowedStatus=['draft','published','archived']; const status=allowedStatus.includes(d.status)?d.status:'published'; const price=d.price===null||d.price===undefined||d.price===''?null:Number(d.price); if(price!==null&&(!Number.isFinite(price)||price<0))return res.status(400).json({error:'Invalid price'});
 const x=await db.query(`INSERT INTO marketplace_listings(user_id,title,description,category,price,currency,status) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`,[req.userId,title,String(d.description||'').slice(0,5000),d.category||null,price,d.currency||'DZD',status]);res.status(201).json({listing:x.rows[0]});
});
app.put('/api/marketplace/:id',auth,async(req:any,res)=>{
 const d=req.body||{};const x=await db.query(`UPDATE marketplace_listings SET title=COALESCE($3,title),description=COALESCE($4,description),category=COALESCE($5,category),price=COALESCE($6,price),currency=COALESCE($7,currency),status=COALESCE($8,status),updated_at=NOW() WHERE id=$1 AND user_id=$2 RETURNING *`,[req.params.id,req.userId,d.title,d.description,d.category,d.price,d.currency,d.status]);if(!x.rows[0])return res.status(404).json({error:'Listing not found'});res.json({listing:x.rows[0]});
});

// Community — publish work, react and comment. Content moderation hooks should be added before public scale.
app.get('/api/community/posts',auth,async(req:any,res)=>{
 const x=await db.query(`SELECT p.*,u.email,COALESCE(pr.display_name,u.email) author,COUNT(DISTINCT r.user_id)::int reactions,COUNT(DISTINCT c.id)::int comments,BOOL_OR(r.user_id=$1) FILTER (WHERE r.user_id IS NOT NULL) reacted FROM community_posts p JOIN users u ON u.id=p.user_id LEFT JOIN user_profiles pr ON pr.user_id=p.user_id LEFT JOIN community_reactions r ON r.post_id=p.id LEFT JOIN community_comments c ON c.post_id=p.id GROUP BY p.id,u.email,pr.display_name ORDER BY p.created_at DESC LIMIT 100`,[req.userId]);res.json({posts:x.rows});
});
app.post('/api/community/posts',auth,async(req:any,res)=>{
 const body=String(req.body?.body||'').trim();if(!body)return res.status(400).json({error:'Post body required'});if(body.length>5000)return res.status(400).json({error:'Post too long'});
 const x=await db.query('INSERT INTO community_posts(user_id,body,media) VALUES($1,$2,$3) RETURNING *',[req.userId,body,JSON.stringify(req.body?.media||[])]);res.status(201).json({post:x.rows[0]});
});
app.post('/api/community/posts/:id/react',auth,async(req:any,res)=>{await db.query('INSERT INTO community_reactions(user_id,post_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.userId,req.params.id]);res.json({ok:true});});
app.delete('/api/community/posts/:id/react',auth,async(req:any,res)=>{await db.query('DELETE FROM community_reactions WHERE user_id=$1 AND post_id=$2',[req.userId,req.params.id]);res.json({ok:true});});
app.get('/api/community/posts/:id/comments',auth,async(req:any,res)=>{const x=await db.query(`SELECT c.*,COALESCE(p.display_name,u.email) author FROM community_comments c JOIN users u ON u.id=c.user_id LEFT JOIN user_profiles p ON p.user_id=c.user_id WHERE c.post_id=$1 ORDER BY c.created_at ASC`,[req.params.id]);res.json({comments:x.rows});});
app.post('/api/community/posts/:id/comments',auth,async(req:any,res)=>{const body=String(req.body?.body||'').trim();if(!body)return res.status(400).json({error:'Comment required'});if(body.length>2000)return res.status(400).json({error:'Comment too long'});const x=await db.query('INSERT INTO community_comments(post_id,user_id,body) VALUES($1,$2,$3) RETURNING *',[req.params.id,req.userId,body]);res.status(201).json({comment:x.rows[0]});});

app.use((err:any,req:any,res:any,_next:any)=>{
 console.error('Unhandled API error', {method:req.method,path:req.path,error:err?.message});
 if(res.headersSent)return;
 res.status(500).json({error:'Internal server error'});
});

const server=app.listen(Number(process.env.PORT||3000),()=>console.log('WorkRadar v2.7 running'));
async function shutdown(signal:string){console.log(`Received ${signal}, shutting down...`);server.close(()=>db.end().finally(()=>process.exit(0)));setTimeout(()=>process.exit(1),10000).unref();}
process.on('SIGTERM',()=>shutdown('SIGTERM'));
process.on('SIGINT',()=>shutdown('SIGINT'));
