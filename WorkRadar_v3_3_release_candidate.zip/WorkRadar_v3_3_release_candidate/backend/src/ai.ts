export async function askAI(messages:any[],context:any){
 if(!process.env.AI_API_KEY) return 'المساعد الذكي يحتاج إعداد مفتاح مزود الذكاء الاصطناعي على الخادم.';
 const system=`You are WorkRadar AI. Help users find opportunities, understand requirements, improve skills and prepare applications. Be practical and concise. Context: ${JSON.stringify(context)}`;
 const r=await fetch(`${process.env.AI_BASE_URL||'https://api.openai.com/v1'}/chat/completions`,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${process.env.AI_API_KEY}`},body:JSON.stringify({model:process.env.AI_MODEL||'gpt-5-mini',messages:[{role:'system',content:system},...messages]})});
 if(!r.ok) throw new Error(`AI provider error ${r.status}`);
 const d:any=await r.json();return d.choices?.[0]?.message?.content||'لم يتم إنشاء رد.';
}