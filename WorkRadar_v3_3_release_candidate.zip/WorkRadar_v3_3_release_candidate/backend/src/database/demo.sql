INSERT INTO opportunities(title,description,source_name,category,required_devices,required_skills,minimum_hours,experience_level)
VALUES
('كتابة محتوى للمبتدئين','فرصة للكتابة وصناعة المحتوى.','WorkRadar Demo','writing','["phone","computer"]','["writing"]',1,'beginner'),
('إدخال بيانات عن بعد','تنظيم ومراجعة البيانات.','WorkRadar Demo','data','["computer"]','[]',2,'beginner'),
('مساعد افتراضي','تنظيم المهام والرسائل.','WorkRadar Demo','assistant','["phone"]','[]',1,'beginner')
ON CONFLICT DO NOTHING;
