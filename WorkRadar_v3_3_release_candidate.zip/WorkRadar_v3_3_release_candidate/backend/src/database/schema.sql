CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_profiles(
 user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 display_name TEXT,
 devices JSONB NOT NULL DEFAULT '[]',
 skills JSONB NOT NULL DEFAULT '[]',
 goals JSONB NOT NULL DEFAULT '[]',
 available_hours_per_day NUMERIC DEFAULT 1,
 experience_level TEXT DEFAULT 'beginner',
 language TEXT DEFAULT 'ar',
 updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS opportunities(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 source_name TEXT,
 source_url TEXT,
 category TEXT,
 required_devices JSONB NOT NULL DEFAULT '[]',
 required_skills JSONB NOT NULL DEFAULT '[]',
 minimum_hours NUMERIC,
 experience_level TEXT,
 status TEXT NOT NULL DEFAULT 'active',
 created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS saved_opportunities(
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 opportunity_id UUID REFERENCES opportunities(id) ON DELETE CASCADE,
 created_at TIMESTAMPTZ DEFAULT NOW(),
 PRIMARY KEY(user_id,opportunity_id)
);

CREATE TABLE IF NOT EXISTS radar_filters(
 user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 categories JSONB NOT NULL DEFAULT '[]',
 minimum_match INTEGER NOT NULL DEFAULT 50,
 enabled BOOLEAN NOT NULL DEFAULT TRUE,
 updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS opportunity_alerts(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 opportunity_id UUID REFERENCES opportunities(id) ON DELETE CASCADE,
 match_score INTEGER NOT NULL,
 reason TEXT,
 is_read BOOLEAN NOT NULL DEFAULT FALSE,
 created_at TIMESTAMPTZ DEFAULT NOW(),
 UNIQUE(user_id,opportunity_id)
);

CREATE TABLE IF NOT EXISTS assistant_messages(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 role TEXT NOT NULL CHECK(role IN ('user','assistant')),
 content TEXT NOT NULL,
 created_at TIMESTAMPTZ DEFAULT NOW()
);


CREATE TABLE IF NOT EXISTS device_tokens(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 token TEXT NOT NULL,
 platform TEXT,
 language TEXT DEFAULT 'ar',
 created_at TIMESTAMPTZ DEFAULT NOW(),
 UNIQUE(user_id,token)
);

CREATE INDEX IF NOT EXISTS opportunities_created_idx ON opportunities(created_at DESC);
CREATE INDEX IF NOT EXISTS alerts_user_created_idx ON opportunity_alerts(user_id,created_at DESC);


CREATE TABLE IF NOT EXISTS inbox_messages(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 type TEXT NOT NULL DEFAULT 'system',
 title TEXT NOT NULL,
 body TEXT NOT NULL DEFAULT '',
 metadata JSONB NOT NULL DEFAULT '{}',
 is_read BOOLEAN NOT NULL DEFAULT FALSE,
 created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_inbox_user_created ON inbox_messages(user_id,created_at DESC);

CREATE TABLE IF NOT EXISTS agent_tasks(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title TEXT NOT NULL,
 instructions TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'active',
 schedule JSONB,
 last_run_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ DEFAULT NOW(),
 updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_agent_tasks_user_status ON agent_tasks(user_id,status);

CREATE TABLE IF NOT EXISTS agent_task_runs(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 task_id UUID NOT NULL REFERENCES agent_tasks(id) ON DELETE CASCADE,
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 status TEXT NOT NULL DEFAULT 'queued',
 summary TEXT NOT NULL DEFAULT '',
 result JSONB NOT NULL DEFAULT '{}',
 started_at TIMESTAMPTZ,
 finished_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_agent_task_runs_task_created ON agent_task_runs(task_id,created_at DESC);
ALTER TABLE agent_tasks ADD COLUMN IF NOT EXISTS next_run_at TIMESTAMPTZ;
ALTER TABLE agent_tasks ADD COLUMN IF NOT EXISTS run_count INTEGER NOT NULL DEFAULT 0;


-- WorkRadar v2.0: professional activity, marketplace and community foundations.
CREATE TABLE IF NOT EXISTS applications(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 opportunity_id UUID REFERENCES opportunities(id) ON DELETE SET NULL,
 company TEXT,
 role_title TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'planned' CHECK(status IN ('planned','submitted','interview','offer','rejected','closed')),
 notes TEXT NOT NULL DEFAULT '',
 applied_at TIMESTAMPTZ,
 follow_up_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ DEFAULT NOW(),
 updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_applications_user_status ON applications(user_id,status,updated_at DESC);

CREATE TABLE IF NOT EXISTS marketplace_listings(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 category TEXT,
 price NUMERIC,
 currency TEXT NOT NULL DEFAULT 'DZD',
 status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','published','archived')),
 created_at TIMESTAMPTZ DEFAULT NOW(),
 updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_marketplace_status_created ON marketplace_listings(status,created_at DESC);

CREATE TABLE IF NOT EXISTS community_posts(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 body TEXT NOT NULL,
 media JSONB NOT NULL DEFAULT '[]',
 created_at TIMESTAMPTZ DEFAULT NOW(),
 updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_community_posts_created ON community_posts(created_at DESC);

CREATE TABLE IF NOT EXISTS community_reactions(
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 post_id UUID NOT NULL REFERENCES community_posts(id) ON DELETE CASCADE,
 created_at TIMESTAMPTZ DEFAULT NOW(),
 PRIMARY KEY(user_id,post_id)
);

CREATE TABLE IF NOT EXISTS community_comments(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 post_id UUID NOT NULL REFERENCES community_posts(id) ON DELETE CASCADE,
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 body TEXT NOT NULL,
 created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_comments_post_created ON community_comments(post_id,created_at ASC);

-- v2.7 safety indexes and constraints for public-scale readiness.
CREATE INDEX IF NOT EXISTS idx_inbox_user_unread ON inbox_messages(user_id,is_read,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tasks_due ON agent_tasks(status,next_run_at);
