import dotenv from 'dotenv'; dotenv.config();
const base=process.env.API_URL||'http://api:3000';
const secret=process.env.WORKER_SECRET||'';
const headers={'x-worker-secret':secret,'content-type':'application/json'};
const sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms));
async function api(path:string,init:any={}){const r=await fetch(base+path,{...init,headers:{...headers,...(init.headers||{})}});if(!r.ok)throw new Error(await r.text());return r.json();}
async function execute(task:any){
 const text=(task.instructions||task.title||'').toLowerCase();
 if(/فرص|وظيف|عمل|opportun|job/.test(text)){
  const data=await api(`/internal/agent/opportunities/${task.user_id}`);
  if(data.disabled)return {summary:'مراقبة الفرص متوقفة حسب إعدادات Radar.',result:{agent:'Opportunity Hunter',disabled:true}};
  const notify=await api(`/internal/agent/opportunities/${task.user_id}/notify`,{method:'POST',body:JSON.stringify({items:data.opportunities})});
  return {summary:notify.inserted.length?`Opportunity Hunter وجد ${notify.inserted.length} فرصة جديدة مطابقة وأرسلها إلى البريد.`:`Opportunity Hunter راجع الفرص الحالية ولم يجد فرصًا جديدة مطابقة في هذه الدورة.`,result:{agent:'Opportunity Hunter',checked:data.opportunities.length,new:notify.inserted.length,minimumMatch:data.minimumMatch}};
 }
 if(/سيرة|cv|resume/.test(text)) return {summary:`CV Agent سجّل مهمة «${task.title}» للمراجعة الذكية.`,result:{agent:'CV Agent',action:'cv_review'}};
 if(/طلب|تقديم|application/.test(text)) return {summary:`Application Agent أكمل دورة متابعة للمهمة «${task.title}».`,result:{agent:'Application Agent',action:'application_followup'}};
 return {summary:`المساعد أكمل دورة عمل للمهمة «${task.title}» وسيواصل المتابعة حسب الجدولة.`,result:{agent:'WorkRadar Agent',action:'task_cycle'}};
}
async function tick(){const {tasks}=await api('/internal/worker/tasks');for(const task of tasks){try{const {run}=await api(`/internal/worker/tasks/${task.id}/run`,{method:'POST'});const out=await execute(task);await api(`/internal/worker/runs/${run.id}/complete`,{method:'POST',body:JSON.stringify(out)});console.log('completed',task.id);}catch(e){console.error('task failed',e);}}}
(async()=>{console.log('WorkRadar worker started');while(true){try{await tick();}catch(e){console.error(e)}await sleep(30000);}})();
