# WorkRadar Privacy Policy (Draft)

WorkRadar stores account details, profile data, tasks, messages and user-created marketplace/community content needed to provide the service. Passwords are stored as password hashes, not plain text. Authentication tokens and production secrets must be protected by the deployment environment.

Before public release, publish this policy at a public HTTPS URL and replace this draft with final contact, retention, deletion and processor details.
