# WorkRadar Terms of Service (Draft)

Users are responsible for content they publish and for complying with applicable laws. WorkRadar must not represent automated results as guaranteed employment, income, or human-reviewed decisions.

Before public release, replace this draft with final jurisdiction, contact, dispute and marketplace/payment terms.
