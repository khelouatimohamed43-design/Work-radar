import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main()=>runApp(const WorkRadar());

class API{
 static const base=String.fromEnvironment('API_BASE_URL',defaultValue:'');
 static const _timeout=Duration(seconds:20);
 static String _url(String p){
  if(base.isEmpty)throw Exception('API_BASE_URL غير مضبوط. استعمل رابط HTTPS الخاص بالخادم.');
  if(!base.startsWith('https://') && !base.startsWith('http://'))throw Exception('رابط الخادم غير صالح');
  return '${base.replaceFirst(RegExp(r'/+$'), '')}$p';
 }
 static String token='';
 static Map<String,String> get h=>{'Content-Type':'application/json',if(token.isNotEmpty)'Authorization':'Bearer $token'};
 static dynamic _decode(http.Response r){
  dynamic d={};
  if(r.body.isNotEmpty){try{d=jsonDecode(r.body);}catch(_){d={'error':'استجابة غير صالحة من الخادم'};}}
  if(r.statusCode>=300)throw Exception(d is Map?(d['error']??'API error'):'API error');
  return d;
 }
 static Future<dynamic> get(String p)async=>_decode(await http.get(Uri.parse(_url(p)),headers:h).timeout(_timeout));
 static Future<dynamic> post(String p,dynamic b)async=>_decode(await http.post(Uri.parse(_url(p)),headers:h,body:jsonEncode(b)).timeout(_timeout));
 static Future<dynamic> put(String p,dynamic b)async=>_decode(await http.put(Uri.parse(_url(p)),headers:h,body:jsonEncode(b)).timeout(_timeout));
}


class WorkRadar extends StatefulWidget{const WorkRadar({super.key});@override State<WorkRadar>createState()=>_WorkRadarState();}
class _WorkRadarState extends State<WorkRadar>{
 Locale locale=const Locale('ar');
 @override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,locale:locale,theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.indigo),home:API.token.isEmpty?Login(onLanguage:(l)=>setState(()=>locale=Locale(l)),onLogin:()=>setState(()=>{})):Shell(onLogout:()=>setState(()=>API.token='')));
}

class Login extends StatefulWidget{final VoidCallback onLogin;final ValueChanged<String> onLanguage;const Login({super.key,required this.onLogin,required this.onLanguage});@override State<Login>createState()=>_LoginState();}
class _LoginState extends State<Login>{final email=TextEditingController(),pass=TextEditingController();bool register=false,busy=false;
Future<void>go()async{setState(()=>busy=true);try{final d=await API.post(register?'/api/auth/register':'/api/auth/login',{'email':email.text.trim(),'password':pass.text});API.token=d['token'];widget.onLogin();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}if(mounted)setState(()=>busy=false);}
@override Widget build(BuildContext c)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(28),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.radar,size:70),const SizedBox(height:12),Text('WorkRadar',style:Theme.of(c).textTheme.headlineMedium),const SizedBox(height:20),TextField(controller:email,decoration:const InputDecoration(labelText:'البريد الإلكتروني')),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'كلمة المرور')),const SizedBox(height:16),FilledButton(onPressed:busy?null:go,child:Text(register?'إنشاء حساب':'دخول')),TextButton(onPressed:()=>setState(()=>register=!register),child:Text(register?'عندي حساب':'إنشاء حساب جديد')),Wrap(spacing:8,children:['AR','EN','FR'].map((x)=>TextButton(onPressed:()=>widget.onLanguage(x=='AR'?'ar':x=='EN'?'en':'fr'),child:Text(x))).toList())]))));}

class Shell extends StatefulWidget{final VoidCallback onLogout;const Shell({super.key,required this.onLogout});@override State<Shell>createState()=>_ShellState();}
class _ShellState extends State<Shell>{int index=0;late final pages=[const HomePage(),const Discover(),const InboxPage(),const AssistantPage(),const TasksPage(),const MarketplacePage(),const CommunityPage(),const Workshop(),ProfilePage(onLogout:widget.onLogout)];
@override Widget build(BuildContext c)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(body:SafeArea(child:pages[index]),bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations:const[NavigationDestination(icon:Icon(Icons.home),label:'الرئيسية'),NavigationDestination(icon:Icon(Icons.search),label:'الفرص'),NavigationDestination(icon:Icon(Icons.inbox),label:'البريد'),NavigationDestination(icon:Icon(Icons.smart_toy),label:'المساعد'),NavigationDestination(icon:Icon(Icons.task_alt),label:'مهامي'),NavigationDestination(icon:Icon(Icons.storefront),label:'المتجر'),NavigationDestination(icon:Icon(Icons.groups),label:'المجتمع'),NavigationDestination(icon:Icon(Icons.build),label:'الورشة'),NavigationDestination(icon:Icon(Icons.person),label:'حسابي')])));}

class HomePage extends StatefulWidget{const HomePage({super.key});@override State<HomePage>createState()=>_HomePageState();}
class _HomePageState extends State<HomePage>{Map d={};@override void initState(){super.initState();API.get('/api/dashboard').then((x){if(mounted)setState(()=>d=x);});}
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('⚡ WorkRadar')),body:ListView(padding:const EdgeInsets.all(20),children:[Text('مركز العمل الذكي',style:Theme.of(c).textTheme.headlineMedium),const SizedBox(height:15),Card(child:ListTile(leading:const Icon(Icons.work),title:const Text('فرص متاحة'),trailing:Text('${d['activeOpportunities']??'...'}'))),Card(child:ListTile(leading:const Icon(Icons.bookmark),title:const Text('محفوظة'),trailing:Text('${d['saved']??'...'}'))),Card(child:ListTile(leading:const Icon(Icons.notifications),title:const Text('تنبيهات جديدة'),trailing:Text('${d['unreadAlerts']??'...'}'))),const SizedBox(height:18),const Text('اكتشف فرصًا مناسبة لك واستعمل المساعد والورشة من نفس التطبيق.') ]));}

class Discover extends StatefulWidget{const Discover({super.key});@override State<Discover>createState()=>_DiscoverState();}
class _DiscoverState extends State<Discover>{List ops=[];bool loading=true;Future<void>load()async{try{final d=await API.get('/api/opportunities');setState(()=>ops=d['opportunities']??[]);}finally{if(mounted)setState(()=>loading=false);}}@override void initState(){super.initState();load();}
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('🔎 الفرص')),body:loading?const Center(child:CircularProgressIndicator()):RefreshIndicator(onRefresh:load,child:ListView.builder(itemCount:ops.length,itemBuilder:(c,i){final o=ops[i];return Card(child:ListTile(title:Text(o['title']),subtitle:Text('${o['description']}\n🎯 ${o['match']['score']}%'),isThreeLine:true,trailing:IconButton(icon:const Icon(Icons.bookmark_add),onPressed:()=>API.post('/api/opportunities/${o['id']}/save',{})));})));}

class AssistantPage extends StatefulWidget{const AssistantPage({super.key});@override State<AssistantPage>createState()=>_AssistantPageState();}
class _AssistantPageState extends State<AssistantPage>{final input=TextEditingController();final List<Map<String,String>> msgs=[];bool busy=false;
Future<void>send()async{final t=input.text.trim();if(t.isEmpty||busy)return;setState(()=>msgs.add({'r':'u','c':t}));input.clear();setState(()=>busy=true);try{final d=await API.post('/api/assistant/chat',{'message':t});setState(()=>msgs.add({'r':'a','c':d['answer']}));}catch(e){setState(()=>msgs.add({'r':'a','c':'تعذر الاتصال: $e'}));}if(mounted)setState(()=>busy=false);}
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('🤖 مساعد WorkRadar')),body:Column(children:[Expanded(child:msgs.isEmpty?const Center(child:Text('مثال: عندي هاتف وPC، ما هي الفرص المناسبة؟')):ListView.builder(padding:const EdgeInsets.all(10),itemCount:msgs.length,itemBuilder:(c,i)=>Align(alignment:msgs[i]['r']=='u'?Alignment.centerRight:Alignment.centerLeft,child:Card(child:Padding(padding:const EdgeInsets.all(10),child:Text(msgs[i]['c']!)))))),if(busy)const LinearProgressIndicator(),Padding(padding:const EdgeInsets.all(8),child:Row(children:[Expanded(child:TextField(controller:input,onSubmitted:(_)=>send(),decoration:const InputDecoration(hintText:'اكتب سؤالك...'))),IconButton(onPressed:send,icon:const Icon(Icons.send))]))]));}

class InboxPage extends StatefulWidget{const InboxPage({super.key});@override State<InboxPage>createState()=>_InboxPageState();}
class _InboxPageState extends State<InboxPage>{List messages=[];bool loading=true;Future<void>load()async{try{final d=await API.get('/api/inbox');messages=d['messages']??[];}finally{if(mounted)setState(()=>loading=false);}}@override void initState(){super.initState();load();}@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('📬 بريد WorkRadar')),body:loading?const Center(child:CircularProgressIndicator()):messages.isEmpty?const Center(child:Text('مازال ما كاين حتى رسالة. نتائج المساعد والمهام راح توصل هنا.')):RefreshIndicator(onRefresh:load,child:ListView.builder(itemCount:messages.length,itemBuilder:(c,i){final m=messages[i];return Card(child:ListTile(leading:Icon(m['is_read']==true?Icons.mark_email_read:Icons.mark_email_unread),title:Text(m['title']??''),subtitle:Text(m['body']??''),onTap:()async{await API.post('/api/inbox/${m['id']}/read',{});load();}));})));}

class Workshop extends StatelessWidget{const Workshop({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('🛠️ الورشة')),body:ListView(padding:const EdgeInsets.all(20),children:const[Card(child:ListTile(leading:Icon(Icons.edit),title:Text('الكتابة الذكية'))),Card(child:ListTile(leading:Icon(Icons.description),title:Text('CV وطلبات العمل'))),Card(child:ListTile(leading:Icon(Icons.image),title:Text('أوصاف الصور')))]));}

class ProfilePage extends StatefulWidget{final VoidCallback onLogout;const ProfilePage({super.key,required this.onLogout});@override State<ProfilePage>createState()=>_ProfilePageState();}
class _ProfilePageState extends State<ProfilePage>{final name=TextEditingController();@override void initState(){super.initState();API.get('/api/me/profile').then((d){name.text=d['profile']['display_name']??'';if(mounted)setState((){});});}
Future<void>save()async{await API.put('/api/me/profile',{'displayName':name.text,'devices':['phone'],'skills':[],'goals':['income'],'availableHours':2,'experienceLevel':'beginner','language':'ar'});if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم حفظ الملف')));}
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('👤 حسابي')),body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[TextField(controller:name,decoration:const InputDecoration(labelText:'الاسم')),const SizedBox(height:15),FilledButton(onPressed:save,child:const Text('حفظ الملف')),const Spacer(),OutlinedButton(onPressed:widget.onLogout,child:const Text('تسجيل الخروج'))])));}


class TasksPage extends StatefulWidget{const TasksPage({super.key});@override State<TasksPage>createState()=>_TasksPageState();}
class _TasksPageState extends State<TasksPage>{final input=TextEditingController();List tasks=[];bool loading=true;
Future<void>load()async{try{final d=await API.get('/api/tasks');tasks=d['tasks']??[];}catch(_){tasks=[];}finally{if(mounted)setState(()=>loading=false);}}
Future<void>add()async{final t=input.text.trim();if(t.isEmpty)return;try{await API.post('/api/tasks',{'title':t});input.clear();await load();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر إنشاء المهمة: $e')));}}
@override void initState(){super.initState();load();}
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('⚙️ مهامي والأتمتة')),body:Column(children:[Padding(padding:const EdgeInsets.all(12),child:TextField(controller:input,onSubmitted:(_)=>add(),decoration:InputDecoration(hintText:'مثال: راقب فرص Remote وأرسل المهم للبريد',suffixIcon:IconButton(onPressed:add,icon:const Icon(Icons.add_task))))),Expanded(child:loading?const Center(child:CircularProgressIndicator()):tasks.isEmpty?const Center(child:Text('مازال ما كاين حتى مهمة. أعطِ للمساعد أمرًا أو أنشئ مهمة هنا.')):RefreshIndicator(onRefresh:load,child:ListView.builder(itemCount:tasks.length,itemBuilder:(c,i){final t=tasks[i];return Card(child:ListTile(leading:const Icon(Icons.smart_toy),title:Text(t['title']??'مهمة'),subtitle:Text('الحالة: ${t['status']??'نشطة'}')));}))) ]));}

class MarketplacePage extends StatefulWidget{const MarketplacePage({super.key});@override State<MarketplacePage>createState()=>_MarketplacePageState();}
class _MarketplacePageState extends State<MarketplacePage>{List items=[];bool loading=true;final title=TextEditingController(),description=TextEditingController(),price=TextEditingController();
Future<void>load()async{try{final d=await API.get('/api/marketplace');items=d['items']??d['listings']??[];}catch(_){items=[];}finally{if(mounted)setState(()=>loading=false);}}
Future<void>create()async{if(title.text.trim().isEmpty)return;try{await API.post('/api/marketplace',{'title':title.text.trim(),'description':description.text.trim(),'price':double.tryParse(price.text.trim())??0});title.clear();description.clear();price.clear();if(mounted)Navigator.pop(context);await load();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}}
void sheet()=>showModalBottomSheet(context:context,isScrollControlled:true,builder:(c)=>Padding(padding:EdgeInsets.fromLTRB(20,20,20,20+MediaQuery.of(c).viewInsets.bottom),child:Column(mainAxisSize:MainAxisSize.min,children:[Text('اعرض عملك',style:Theme.of(c).textTheme.titleLarge),TextField(controller:title,decoration:const InputDecoration(labelText:'العنوان')),TextField(controller:description,maxLines:3,decoration:const InputDecoration(labelText:'الوصف')),TextField(controller:price,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'السعر')),const SizedBox(height:12),FilledButton(onPressed:create,child:const Text('نشر في المتجر'))]));
@override void initState(){super.initState();load();}
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('🛍️ سوق WorkRadar')),floatingActionButton:FloatingActionButton.extended(onPressed:sheet,label:const Text('اعرض عملك'),icon:const Icon(Icons.add)),body:loading?const Center(child:CircularProgressIndicator()):items.isEmpty?const Center(child:Text('المتجر جاهز. كن أول واحد يعرض عمله.')):RefreshIndicator(onRefresh:load,child:ListView.builder(padding:const EdgeInsets.all(12),itemCount:items.length,itemBuilder:(c,i){final x=items[i];return Card(child:ListTile(leading:const Icon(Icons.storefront),title:Text(x['title']??'عمل'),subtitle:Text(x['description']??''),trailing:Text('${x['price']??0}')));})));}

class CommunityPage extends StatefulWidget{const CommunityPage({super.key});@override State<CommunityPage>createState()=>_CommunityPageState();}
class _CommunityPageState extends State<CommunityPage>{List posts=[];bool loading=true;final text=TextEditingController();Future<void>load()async{try{final d=await API.get('/api/community/posts');posts=d['posts']??[];}catch(_){posts=[];}finally{if(mounted)setState(()=>loading=false);}}
Future<void>publish()async{final t=text.text.trim();if(t.isEmpty)return;try{await API.post('/api/community/posts',{'body':t});text.clear();await load();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}}
@override void initState(){super.initState();load();}
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('🌐 مجتمع WorkRadar')),body:Column(children:[Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:TextField(controller:text,decoration:const InputDecoration(hintText:'انشر عملك أو مشروعك...'))),IconButton(onPressed:publish,icon:const Icon(Icons.publish))])),Expanded(child:loading?const Center(child:CircularProgressIndicator()):posts.isEmpty?const Center(child:Text('المجتمع جاهز للنشر والتفاعل.')):RefreshIndicator(onRefresh:load,child:ListView.builder(itemCount:posts.length,itemBuilder:(c,i){final p=posts[i];return Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(p['author']??'عضو',style:const TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:8),Text(p['body']??p['content']??''),Row(children:[IconButton(onPressed:()async{await API.post('/api/community/posts/${p['id']}/react',{});await load();},icon:const Icon(Icons.favorite_border)),Text('${p['reactions']??0}'),const SizedBox(width:12),const Icon(Icons.comment_outlined)] )]));}))) ]));}

