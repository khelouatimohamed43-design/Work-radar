# WorkRadar v2.8 — Build Ready

This source package is prepared for Android build validation through GitHub Actions or another Flutter/Android build environment.

Required release configuration:
- API_BASE_URL: public HTTPS backend URL
- POSTGRES_PASSWORD
- JWT_SECRET
- WORKER_SECRET
- CORS_ORIGIN

Before Google Play submission: run Android release build, install on a real device, complete privacy/data declarations, and verify backend production deployment.


## Build status
This package includes a GitHub Actions workflow that generates missing Android platform files before analysis/build, then produces both APK and AAB artifacts. Configure the `API_BASE_URL` GitHub Actions secret with the HTTPS backend URL before a production build.
